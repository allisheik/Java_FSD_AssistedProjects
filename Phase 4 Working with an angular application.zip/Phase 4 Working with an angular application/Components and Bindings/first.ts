let a:number;
a=56;

let b:number=12;

let fname:string="Alli Sheik";

console.log(a+b);
console.log(fname);


function test(num1:number,num2:number){
    return num1+num2;
}

console.log("Addition: "+test(2,3));